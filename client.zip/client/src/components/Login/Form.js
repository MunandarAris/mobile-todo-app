import React from "react";

import { FormControl,Text, Input} from "native-base";

export default function Form({changePassword,changeEmail,email,password}){
    return(

        <FormControl mt="5">

            <FormControl.Label px="2">
                <Text fontSize="lg" color="gray.600" >Email</Text>
            </FormControl.Label>
            <Input mt="1" placeholder="example@gmail.com" size="lg" px="5" py="3" borderWidth="0" shadow="1" type="email" background="white" borderRadius="full" autoComplete="off" value={email} onChangeText={
                (text) => changeEmail(text)
            }/>

            <FormControl.Label px="2" mt="7">
                <Text fontSize="lg" color="gray.600">password</Text>
            </FormControl.Label>
            <Input mt="1" type="password" size="lg" px="5" py="3" borderWidth="0" shadow="1" background="white" value={password} placeholder="Input Your Password" borderRadius="full" onChangeText={
                (text) => changePassword(text)
            }/>
            
        </FormControl>

    )
}