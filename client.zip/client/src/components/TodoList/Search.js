import React from "react";

import { Input,Icon, Box, HStack } from "native-base";

import { Ionicons } from '@expo/vector-icons';

import AsyncStorage from "@react-native-async-storage/async-storage";

export default function Search({navigation,search}){


    const handleLogout = async () => {
        await AsyncStorage.removeItem("idUser");

        navigation.navigate("Login");
    }

    return(


        <Box safeArea px="3">
            <HStack alignItems="center" justifyContent="center">
                <Box borderRadius="full" width="80%" shadow="3" my="3" background="white">
                    <Input
                        placeholder = "Search Task"
                        fontSize = "17"
                        mx = "2"
                        my = "1"
                        borderRadius = "full"
                        px = "4"
                        borderWidth = "0"
                        InputLeftElement = {
                            <Icon
                                ml="2"
                                size="6"
                                color="info.500"
                                as={<Ionicons name="ios-search" />}
                            />
                        }
                        onChangeText={(text) => {search(text)}}
                    />
                </Box>
                <Icon
                    ml="5"
                    size="9"
                    color="info.600"
                    as={<Ionicons name="log-out" />}
                    onPress={handleLogout}
                />
            </HStack>
        </Box>

    )
}