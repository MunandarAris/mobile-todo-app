import React,{useState} from "react";

import { Button,Center,Modal,FormControl,Input,Text, HStack, useToast} from 'native-base';

import { FontAwesome } from '@expo/vector-icons';

import axios from "axios";

import AsyncStorage from "@react-native-async-storage/async-storage";

export default function Form({changing}){

    const [showModal, setShowModal] = useState(false);
    const [form, setForm] = useState("");
    const [loading, setIsLoading] = useState(false);

    const toast = useToast();

    const handleOnSubmit = async () => {

        if(form == "")
        {
            setShowModal(false);
            toast.show({
                title: "Please insert data",
                status: "warning",
                placement : "top",
                size : 'full'
            })
        }
        else 
        {
            
            setIsLoading(true);

            const idUser = await AsyncStorage.getItem('idUser');

            await axios.post("http://192.168.43.188:5000/api/v1/collection",{
                name : form,
                idUser
            });

            changing(form);
            setShowModal(false);
            setIsLoading(false);
            toast.show({
                title: "Data Succes Insert To Database",
                status: "success",
                placement : "top"
            });
            setForm("");
        }

    }

    return(

        <>
            <Center my="3">
                <Button bg="info.500" px="5" py="4" borderRadius="full" w="auto" shadow="4" onPress={() => setShowModal(true)} _pressed={{bg : "info.600"}} >
                    <FontAwesome name="plus" size={40} color="white" />
                </Button>
            </Center>

            {/* Modal */}
            <Modal isOpen={showModal} onClose={() => {setShowModal(false);setForm("")}}>
                <Modal.Content>

                    <Modal.Header alignItems="center">
                        <HStack alignItems="center">
                            <FontAwesome name="plus" size={20} color="black" />
                            <Text fontSize="2xl" ml="2">Add List</Text>
                        </HStack>
                    </Modal.Header>

                    <Modal.Body>
                        <FormControl>
                            <FormControl.Label>
                                <Text fontSize="lg" fontWeight="thin">Name</Text>
                            </FormControl.Label>
                            <Input placeholder="Input Your Task" onChangeText={(value) => setForm(value)} fontSize="lg" p="3"/>
                        </FormControl>
                    </Modal.Body>
                    
                    <Modal.Footer>
                        <Button.Group space={2}>
                            <Button
                                bgColor="red.700"
                                onPress={() => {
                                setShowModal(false);setForm("")
                                }}
                                _pressed={{bg:"red.800"}}
                            >
                                <Text fontSize="lg" color="white">
                                    Cancel
                                </Text>
                            </Button>
                            {
                                loading ?
                                <Button bgColor="info.500" isLoading>
                                    <Text fontSize="lg" color="white">
                                        save
                                    </Text>
                                </Button>
                                :
                                <Button bgColor="info.500" onPress={handleOnSubmit} _pressed={{bg:"info.600"}}>
                                    <Text fontSize="lg" color="white">
                                        save
                                    </Text>
                                </Button>
                            }
                            
                        </Button.Group>
                    </Modal.Footer>
                </Modal.Content>
            </Modal>
        </>

    )
}