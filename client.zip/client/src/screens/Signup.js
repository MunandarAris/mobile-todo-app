import React,{useState} from "react";

import { Box,Center,Text, Button, HStack, View,useToast } from "native-base";

import Logo from '../../assets/noData.svg';

// Import Component Here
import Form from "../components/Signup/Form";

import AsyncStorage from '@react-native-async-storage/async-storage';

import axios from 'axios';

export default function Signup({navigation}){

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setIsLoading] = useState(false);

    const toast = useToast();

    // Handle On Change
    function handleOnChageEmail(text){
        setEmail(text)
    }
    function handleOnChagePassword(text){
        setPassword(text)
    }

    // Handle Submit
    const handeOnSubmit = async () => {

        if(email == "" || password == "")
        {
            toast.show({
                title: "Please insert all filed",
                status: "error",
                placement : "top"
            })
        }
        else
        {
            setIsLoading(true)
            const signup = await axios.post(`http://192.168.43.188:5000/api/v1/signup`,{
                email,
                password
            });

            if(signup.data.status == "Failed")
            {
                toast.show({
                    title: "Email Already Exists",
                    status: "error",
                    placement : "top"
                });

                setEmail("")
                setPassword("")
            }
            else
            {
                const idUser = JSON.stringify(signup.data.message.newUser.id);
                await AsyncStorage.setItem("idUser",idUser);

                toast.show({
                    title: "Register Successfully",
                    status: "success",
                    placement : "top"
                });

                navigation.navigate("Home");

                setEmail("")
                setPassword("")
            }
            
            setIsLoading(false)
            
        }

    }

    return(

        <Box px="6">
    
            <View mt="2">
                <Center>
                    <Logo width="80%" height="35%"/>
                    
                    <Form changeEmail={handleOnChageEmail} email={email} password={password} changePassword={handleOnChagePassword}/>

                    {
                        loading ?  
                        <Button background="info.500" width="100%" borderRadius="full" shadow="2" mt="10" isLoading color="white">
                            <Text fontSize="lg" color="white" px="8" py="1">Sign up</Text>
                        </Button>
                        :
                        <Button background="info.500" width="100%" borderRadius="full" shadow="2" mt="10" _pressed={{backgroundColor:"info.600"}} onPress={handeOnSubmit}>
                            <Text fontSize="lg" color="white" px="8" py="1">Sign up</Text>
                            </Button>
                    }

                    <HStack mt="10">
                        <Text fontSize="lg" color="gray.600">Have Account</Text>
                        <Text fontSize="lg" mx="2" underline color="info.500" onPress={
                        () => navigation.navigate('Login')
                        }>Login</Text>
                        </HStack>
                </Center>
            </View>

        </Box>

    )
}